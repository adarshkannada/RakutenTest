setup Required
Java, selenium, Maven, testng.
related dependencies are added in the POM file.
Build the Project with the dependencies from the POM file.


Steps to Run the test
In the 'PointsActivityPageTest', 
mention unique EmailID in the createAccount Method call. (modify emailID by changing number and text combination)
Run the TestNG.XML file.
TestNG Report would be generated in the Test-Output folder as 'index.html'.
Extent report would be generated in the Test-Output folder as 'RakutenQATestReports.html'.